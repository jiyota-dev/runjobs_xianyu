import{a as t}from"./batchLogFactory-CRfeZSHg.js";const e=t("token-renewal-batches"),c=e.getBatches,n=e.getBatchDetail;export{n as a,c as g};
