import{c as t}from"./batchLogFactory-CRfeZSHg.js";const a=t({batches:"rate-batches",clearLogs:"rate-logs/clear"}),c=a.getBatches,s=a.getBatchDetail,o=a.clearLogs;export{s as a,o as c,c as g};
