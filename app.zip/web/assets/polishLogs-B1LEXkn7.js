import{c as a}from"./batchLogFactory-CRfeZSHg.js";const s=a({batches:"polish-batches",clearLogs:"polish-logs/clear"}),c=s.getBatches,e=s.getBatchDetail,o=s.clearLogs;export{e as a,o as c,c as g};
