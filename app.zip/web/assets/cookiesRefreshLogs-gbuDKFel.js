import{c as t}from"./batchLogFactory-CRfeZSHg.js";const e=t({batches:"cookies-refresh-batches"}),a=e.getBatches,c=e.getBatchDetail;export{c as a,a as g};
